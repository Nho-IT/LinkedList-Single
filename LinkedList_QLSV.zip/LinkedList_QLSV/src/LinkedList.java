public class LinkedList<T> {
    private Node<T> head;
    public Node<T> getHead() {
        return head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    //hiểu cho đúng thì head ban đầu được gán = null
    //Ban đầu danh sách chưa có gì cả ==> Sau này người
    //  ta gọi phương thức thêm node vào linkedlist thì
    //  danh sách hết empty thôi.

    //2 pt addFirt và addLast giúp ta làm điều trên!
    public LinkedList() {
        this.head = null;
    }

    public void traverse() {
        Node<T> tmp = head;
        //In phần tử ra
        while(tmp != null){
            System.out.println(tmp.getData());
            tmp = tmp.getNext();
        }
        
    }
    
    //Thêm phần tử vào đầu LinkedList
    public void addFirst(T item) {
        Node<T> newNode = new Node<>();
        newNode.setData(item);
        newNode.setNext(this.head);

        this.head = newNode;
    }

    //Thêm phần tử vào cuối LinkedList
    public void addLast(T item) {
        if(head == null) addFirst(item);
        else {
            Node<T> newNode = new Node<>(item, null);
            Node<T> tmp = head;
            while(tmp.getNext() != null) {
                tmp = tmp.getNext();
            }
            tmp.setNext(newNode);
        }
    }
    

    //Thêm 1 phần tử vào sau phần tử được chỉ định
    public void insertAfter(T key, T toInsert) {
        Node<T> newNode = new Node<>();
        newNode.setData(toInsert);

        Node<T> tmp = head;

        while(tmp != null && !tmp.getData().equals(key)) {
            tmp = tmp.getNext();
        }
        //==> một là đi về cuối danh sách và không làm gì
        //      hai là tìm được Node có giá trị trùng với key
        //      và sau đó thực hiện chèn newNode vào sau Node đó.

        if(tmp != null) {
            //gán con trỏ next của newNode vào phần tử sau
            //  Node tmp hiện tại
            newNode.setNext(tmp.getNext());
            //Ta sẽ gán next của tmp hiện tại cho newNode => done
            tmp.setNext(newNode);
        }
    }



    //Xóa 1 phần tử bất kỳ
    public void remove(T key) {
        if(head == null) throw new RuntimeException("Không thể xóa");
        //Xóa nếu key ở vị trí đầu tiên
        if(head.getData().equals(key)) {
            this.head = head.getNext();
        }

        //Xóa key nếu key nằm ở vị trí bất kỳ nào khác
        Node<T> prev = null;
        Node<T> cur = head;
        
        //  không có Node nào trùng key thì chạy đến cuối ds
        //  nếu trùng có Node nào trùng key ta thực hiện xóa
        //      node đó
        while(cur != null && !cur.getData().equals(key)) {
            //Nhích 2 con trỏ lên 1 đơn vị
            prev = cur;
            cur = cur.getNext();
        }

        //Cho đến khi đến cuối ds hoặc có 1 phần tử nào 
        //  trùng với key(phần tử muốn xóa)
        if(cur == null) {
            //tức là duyệt qua đến cuối rồi mà không có phần tử nào trùng cả
            throw new RuntimeException("Không thể xóa");
        } else {
            prev.setNext(cur.getNext());//xong 
        }
    }

    //Kiểm tra phần tử có tồn tại không
    public boolean findItem(T item) {
        Node<T> tmp = head;
        while(tmp != null) {
            if(tmp.getData().equals(item)) return true;
            tmp = tmp.getNext();
        }
        return false;

    }

}