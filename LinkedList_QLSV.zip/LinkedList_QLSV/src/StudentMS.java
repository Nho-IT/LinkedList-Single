public class StudentMS {
    //Khởi tạo 1 đối tượng của class LinkedList
    //  có kiểu dữ liệu là Student từ đó có thể truy
    //  cập vào các phương thức của class LinkedList.
    private LinkedList<Student> list;

    //hàm khởi tạo được gọi khi có 1 đối tượng mới của class
    //  được tạo
    public StudentMS() {
        this.list = new LinkedList<>();
    }

    //Phương thức thêm 1 sinh viên
    public void addStudent(Student student) {
        this.list.addLast(student);
    }

    //In ra danh sách sinh viên
    public void printList() {
        this.list.traverse();
    }

    //kiểm tra xem sinh viên có tồn tại không
    public boolean findStudent(Student student) {
        return this.list.findItem(student);
    }

    //Khi danh sách có phần tử rồi mới thực hiện
    //  cập nhật bạn nhé!
    public boolean update(Student student) {
        //Tạo 1 node kiểu Student và gán Node head cho
        //  Node tmp
        Node<Student> tmp = list.getHead();
        while(tmp != null) {
            //lấy ra data của node tí còn so sánh nữa
            Student st = tmp.getData();
            //So sánh id của sinh viên muốn xóa và
            //  các sinh viên có trong ds
            if(st.getId().equals(student.getId())) {

                st.setFullName(student.getFullName());
                st.setAge(student.getAge());
                st.setGpa(student.getGpa());

            }
            tmp = tmp.getNext();
        }
        return false;
    }


    //Xóa 1 sinh viên chỉ định
    public void remove(Student student) {
        this.list.remove(student);
    }

    //Đếm số sinh viên có tên trùng với tên chỉ định
    public int countStudent(String fullName) {
        int count = 0;
        Node<Student> tmp = list.getHead();
        while(tmp != null) {
            Student st = tmp.getData();
            if(st.getFullName().equals(fullName)) {
                count ++;
            }
            tmp = tmp.getNext();
        }
        return count;
    }


    //TẠI SAO KHÔNG TẠO DANH SÁCH TRONG CLASS APP RỒI SỬ DỤNG PT
    //  TRONG LỚP APP LUN? XIN THƯA KHI TA CÓ 1 ĐỐI TƯỢNG MỚI
    //  TA CHỈ CẦN TẠO THÊM 1 CLASS Mới thay cho Student và
    // vào student MS sửa lại 1 câu lệnh là được. MỤC ĐÍCH TẬN DỤNG CODE 
     
}
