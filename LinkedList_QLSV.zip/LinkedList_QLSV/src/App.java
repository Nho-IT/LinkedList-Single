public class App {
    public static void main(String[] args) throws Exception {
        StudentMS sms = new StudentMS();
        // Khởi tạo các sinh viên mới
        Student s1 = new Student("MS001", "Tran Thi A", 18, 9.8f);
        Student s2 = new Student("MS002", "Nguyen Van B", 22, 8.2f);
        Student s3 = new Student("MS003", "Nguyen Thi C", 24, 7.2f);
        Student s4 = new Student("MS004", "Tran Van D", 25, 7.5f);
        Student s5 = new Student("MS005", "Đặng Ngọc Quên", 18, 5.5f);
        //Thêm các danh sách sinh viên vừa tạo vào danh sách
        sms.addStudent(s1);
        sms.addStudent(s2);
        sms.addStudent(s3);
        sms.addStudent(s4);
        sms.addStudent(s5);

        //In danh sách sinh viên ra
        sms.printList();

        //Kiểm tra sinh viên s4 có tồn tại không
        System.out.println(sms.findStudent(s4));

        //Thử cập nhật 1 sinh viên s1 nhé
        Student capNhat = new Student("MS001", "Đặng Ngọc Nhớ", 21, 8.5f);
        sms.update(capNhat);
        sms.printList();

        //Tìm xem có bao nhiêu bạn có tên là "Đặng Ngọc Nhớ" nhé
        System.out.println(sms.countStudent("Đặng Ngọc Nhớ"));
        
        //Thử xóa đi bạn sinh viên s5 nhé
        sms.remove(s5);
        sms.printList();
    }
}
