import java.util.Objects;

public class Student {
    private String id;
    private String fullName;
    private int age;
    private float gpa;

    // phương thức khởi tạo không đối số
    public Student() {

    }

    // phương thức khởi tạo có đối số
    public Student(String id, String fullName, int age, float gpa) {
        this.id = id;
        this.fullName = fullName;
        this.age = age;
        this.gpa = gpa;
    }

    // get, set
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public float getGpa() {
        return gpa;
    }

    public void setGpa(float gpa) {
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "Sinh viên có: id:" + id + ", fullName: " + fullName + ", age: " + age +
                ", gpa: " + gpa;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;

        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((fullName == null) ? 0 : fullName.hashCode());
        result = prime * result + age;
        result = prime * result + Float.floatToIntBits(gpa);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        // Sau khi kiểm tra obj cùng lớp với
        // đối tượng hiện tại ta thực hiện ép kiểu obj
        // để obj có thể truy cập các thuộc tính có trong class Student
        Student other = (Student) obj;

        //làm theo cách gọi phương thức tĩnh sẽ
        // ngắn gọn hơn, có kèm theo xử lý null
        return Objects.equals(id, other.id)
                && Objects.equals(fullName, other.fullName)
                && age == other.age
                && Float.floatToIntBits(gpa) == Float.floatToIntBits(other.gpa);
    }

}
